#!/bin/bash

#tar -czvf logs.tar.gz /home/workspace/SoapUI/logs

rm -rf /home/pruebasCNTI/logs

mkdir /home/pruebasCNTI/logs

mkdir /home/pruebasCNTI/logs/1/
touch /home/pruebasCNTI/logs/1/trace.txt


/opt/soapui/bin/loadtestrunner.sh -s"TestSuite buscaTripletaPorSujeto" -c"TestCase buscaTripletaPorSujeto" -l"LoadTest buscaTripletaPorSujeto" -m150 -n150 -r -f/home/pruebasCNTI/logs/1 /home/phd2014/Documentos/respaldo/Documentos/pruebasSoaPui/buscarTripletaPorSujeto-soapui-project.xml 

